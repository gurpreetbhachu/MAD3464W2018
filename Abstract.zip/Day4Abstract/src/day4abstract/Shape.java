/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day4abstract;

/**
 *
 * @author macstudent
 */
public class Shape 
{
    public static void main(String[] args) 
    {
        Circle obj1 = new Circle();
        obj1.draw();
        obj1.display("This is a Circle");
    }
        
}


abstract class Myshape    //BY USING ABSTRACT NO NEED TO CREATE ANY OBJECT OF THIS AND WE CAN DIRECTLY CALL THE METHODE USING CLASS NAME ONLY
{
    int x, y;
    
    abstract void draw();
    
    void display(String message)
    {
        System.out.println(message);
    }
}

class Circle extends Myshape
{

    @Override
    void draw() 
    {
        System.out.println("Drawing circle");
        super.x = 20;
        super.y = 30;
        
        System.out.println("X: "+super.x);
        System.out.println("Y: "+super.y);
    }
}

abstract class Rectangle extends Myshape
{
    int h;
    
    abstract void draw();
}
