/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day4arraylist;

/**
 *
 * @author macstudent
 */
public class Books {
    int bookID , bookRating;
    String bookTitle;
    
    Books()
    {
        this.bookID = 0;
        this.bookTitle = "Unknown";
        this.bookRating = 0;
    }
    
    Books(int bookID, String bookTitle, int bookRating)
    {
        this.bookID = bookID;
        this.bookRating = bookRating;
        this.bookTitle = bookTitle;
    }
    
    void setID(int ID)
    {
        this.bookID = ID;
    }
    
    int getID()
    {
        return this.bookID;
    }
    
    void setTitle(String title)
    {
        this.bookTitle = title;
    }
    
    String getTitle()
    {
        return this.bookTitle;
    }
 
    void setRating(int rate)
    {
        this.bookRating = rate;
    }
    
    int getRating()
    {
        return this.bookRating;
    }
    
    void displayInfo() 
    {
       System.out.println("BookID : " + this.bookID + "\n Book Title : " + this.bookTitle + "\n Book Rating : " + this.bookRating);
   }
    
}
