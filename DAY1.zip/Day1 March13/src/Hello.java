/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Arrays;
/**
 *
 * @author macstudent
 */
public class Hello //class name = file name (always)
{
    public static void main(String[] args)
    {
        //while declaring variable first letter should be in lowercase
        int number = 10; 
        float percentage;
        char vowel = 'a';
        String firstName = "GSB";
        
        //PrintingOutput
        //ln = new line
        //System = class in java 
        System.out.println("Value of number : " +number);
        
        // use "f" while defining float value
        percentage = 78.6f;
        System.out.println("Value of % : " +percentage);
        
        System.out.println("Vowel : " +vowel);
        System.out.println("First Name : " +firstName);
        
        //conditions
        if(number>10)
        {
            System.out.println("Number More than 10");
        }
        else if (number==10)
        {
            System.out.println("Number Equal to 10");
        }
        
        // Case condition using SWITCH (int)
        switch (number)
        {
            case 10:
                System.out.println("Value is 10");
                break;
            
            case 20:
                System.out.println("Value is 20");
                break;
                
            case 30:
                System.out.println("Value is 30");
                break;
                
            default:
                System.out.println("No Matching Value");
                break;
        }
        
        
        vowel = 'x';
        switch (vowel)
        {
            case 'a':
                System.out.println(":: VOWEL ::");
                break;
                
            default:
                System.out.println("No Vowel Value");
                break;
        }
        
        String province = "Alberta";
        switch (province)
        {
            case "Ontario":
                System.out.println("ON");
                break;
            
            case "Alberta":
                System.out.println("AB");
                break;
                
            case "Nova Scotia":
                System.out.println("NV");
                break;
                
            default:
                System.out.println("= No Matching Value= ");
                break;
        }
        
        //Creating Array using new keyword and with size 5
        
        int numbers[] = new int[5];
        int i;
        
        for(i=0;i<4;i++)        //OR i<arrayname.length
        {
            numbers[i] = 10;
            System.out.println("Numbers [" +i+ "] =" +numbers[i]);
        }
        
        System.out.println("=============");
        
        for(i=0;i<numbers.length;i++)        
        {
            numbers[i] = (int)(Math.random()*100);
            System.out.println("Numbers [" +i+ "] =" +numbers[i]);
        }
        
        System.out.println("=============");
        
        //
        
        double PI_VALUE = Math.PI;
        double power = Math.pow(2, 2);
        Math.sqrt(144);
        Math.abs(PI_VALUE);
        
        float grades[][] = new float [3][4];
        
        for (i=0; i<3; i++)
        {
            for(int j=0 ;j<4; j++)
            {
                grades[i][j] = 10.0f;
            }
        }
        
        System.out.println("=============");
        //Sorting in Ascending Order
        
        Arrays.sort(numbers);       //need to import array util "ON TOP"
        for(i=0;i<numbers.length;i++)   
        {
            numbers[i] = (int)(Math.random()*10);
            System.out.println("No. [" +i+ "] =" +numbers[i]);
        }
        
        System.out.println("=============");
        
        for(int x=1; x<=5; x++)
        {
            for (int y=1; y<=5; y++)
            {
                if(x==1 || x==5 || y==1 || y==5)
                {
                    System.out.print("* ");
                }
                else
                {
                    System.out.print("  ");
                }
            }
            System.out.println();
        }
        
        System.out.println("=============");
        
        for(int a=1; a<=5; a++)
        {
            for (int b=1; b<=5; b++)
            {
                if(a==1 || a==5 || b==1 || b==5)
                {
                    System.out.print(b+" ");
                }
                else
                {
                    System.out.print("  ");
                }
            }
            System.out.println();
        }
    }
}
