/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day3interface;

/**
 *
 * @author macstudent
 */
public class Day3Interface {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Addition obj1 = new Addition();
        obj1.display();
        
        counting obj2 = new counting();
        obj2.display();
        
        A obj3 = new A();
        obj3.display();
        obj3.CalMultiplication();
        
        B obj4 = new B();
        obj4.display();
        obj4.CalDivision();
        obj4.CalMultiplication();
        
        C obj5 = new C();
    }
    
}

interface Arithmetic
{
    int n1 = 10;
    int n2 = 10;
    void display();
    
}

class Addition implements Arithmetic
{
    //int n1 = 20;
    //int n2 = 100;

    @Override
    public void display() 
    {
        System.out.println(n1 + " + " + n2 + " = " +(n1+n2));
    }
    
}

class counting extends Addition
{

}

interface multiplication extends Arithmetic
{
    void CalMultiplication();
}

class A implements multiplication
{

    @Override
    public void CalMultiplication() 
    {           
        System.out.println("Multiplication:: "+n1 + " * " + n2 + " = " +(n1+n2));
    }

    @Override
    public void display() 
    {
        System.out.println("n1: "+n1+" n2: "+n2);
    }
    
}

interface division extends Arithmetic
{
    void CalDivision();
}

class B extends Addition implements division, multiplication
{

    @Override
    public void CalDivision() 
    {
        System.out.println("Division:: "+n1 + " / " + n2 + " = " +(n1/n2));   
    }

    @Override
    public void display() 
    {
        System.out.println("In Class B");
        System.out.println("n1: "+n1+" n2: "+n2);
    }

    @Override
    public void CalMultiplication() 
    {
        System.out.println("Multiplication(From Class B):: "+n1 + " * " + n2 + " = " +(n1+n2));
    }
    
}

class C extends B
{
    int c1 = 20;
}