/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.*;
/**
 *
 * @author 648318
 */
public class JDBCOperations {
    static Connection conn;
    static PreparedStatement stmt;
    static ResultSet rs;
    static String USER = "root";
    static String PASS = "";
    
    public static void main(String [] args)
    {
        connectDB();
        System.out.println("------------------------------------------------------------------------");
        selectDB();
        System.out.println("------------------------------------------------------------------------");
        insertDB();
        System.out.println("------------------------------------------------------------------------");
        selectDB();
        System.out.println("------------------------------------------------------------------------");
        //deleteDB();
        System.out.println("------------------------------------------------------------------------");
    }
    
    static void connectDB()
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost/MADWinter18", USER, PASS);
            
        }
        catch(Exception ex)
                {
                    ex.printStackTrace();
                }
    }
    
    static void insertDB()
    {
       try
       {
           stmt = conn.prepareStatement("INSERT INTO Person values(?,?,?,?)");
           stmt.setInt(1, 101);
           stmt.setString(2, "Gurpreet");
           stmt.setString(3, "Singh");
           stmt.setInt(4, 12);
           
           
           int i = stmt.executeUpdate();
           System.out.println(i+ " record inserted");
       }
       catch(Exception ex)
       {
           ex.printStackTrace();
       }
    }
    
    static void selectDB()
    {
        try
        {
            stmt = conn.prepareStatement("SELECT * FROM Person");
            rs = stmt.executeQuery();
            
            while(rs.next())
            {
                System.out.println("ID: " +rs.getInt(1)+ " Name: " +rs.getString("FirstName")+ "" +rs.getString("LastName")+ " Age: " +rs.getInt("Age"));
            }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
    
    static void deleteDB()
    {
        try
        {
            stmt = conn.prepareStatement("DELETE FROM Person Where id=?");
            stmt.setInt(1, 101);
            
            int nrec = stmt.executeUpdate();
            System.err.println(nrec+ " Record Deleted");
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
    
    static void updateDB()
    {
        try
        {
            stmt = conn.prepareStatement("UPDATE Person");
            rs = stmt.executeQuery();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
}
